$env:DJANGO_SECRET_KEY="dz-!!yla4neu(6k1o*h1mdk-*m^md^(*a2s3k@%@0h7y24vevh"
$env:DJANGO_DEBUG="1"
$env:DJANGO_ALLOWED_HOSTS="127.0.0.1,localhost"
python manage.py runserver

