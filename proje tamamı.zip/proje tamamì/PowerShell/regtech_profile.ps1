# RegTech helpers (PS5.1 compatible, ASCII-only)

# Default root (change if needed)
$env:REGTECH_ROOT = "C:\Users\cemre\OneDrive\Desktop\ollamak\mevzuat_django"

function Get-RegTechRoot {
  if($env:REGTECH_ROOT -and (Test-Path $env:REGTECH_ROOT)){
    return (Resolve-Path $env:REGTECH_ROOT).Path
  }

  $here = (Get-Location).Path
  if(Test-Path (Join-Path $here "manage.py")){
    $env:REGTECH_ROOT = $here
    return $here
  }

  throw "RegTech root bulunamadi. Proje klasorune cd yap ya da `$env:REGTECH_ROOT ayarla."
}

function Use-RegTechRoot {
  param([Parameter(Mandatory=$true)][scriptblock]$Script)

  $root = Get-RegTechRoot
  Push-Location $root
  try { & $Script } finally { Pop-Location }
}

function Ensure-RegTechEnv {
  if([string]::IsNullOrWhiteSpace($env:DJANGO_DEBUG)){ $env:DJANGO_DEBUG = "1" }
  if([string]::IsNullOrWhiteSpace($env:DJANGO_ALLOWED_HOSTS)){ $env:DJANGO_ALLOWED_HOSTS = "127.0.0.1,localhost" }

  if([string]::IsNullOrWhiteSpace($env:DJANGO_SECRET_KEY)){
    $code2 = 'from django.core.management.utils import get_random_secret_key as g; print(g())'
    $py = Get-Command python -ErrorAction SilentlyContinue
    if(-not $py){ throw "python bulunamadi. once conda activate dj310 yap." }
    $sk = & $py.Source -c $code2
    $env:DJANGO_SECRET_KEY = ($sk | Select-Object -First 1).Trim()
  }
}

function run_smoke {
  param(
    [string]$BaseUrl="http://127.0.0.1:8000",
    [int]$CompanyId=1,
    [int]$ObligationId=1,
    [switch]$AutoStartServer,
    [switch]$StopServerAfter,
    [switch]$Quiet,
    [string]$DumpJsonDir="",
    [int]$TimeoutMs=3000,
    [string]$ReportPath=".\smoke_report.json"
  )

  Use-RegTechRoot {
    $p = Join-Path (Get-RegTechRoot) "run_smoke.ps1"
    if(-not (Test-Path $p)){ throw "run_smoke.ps1 bulunamadi: $p" }

    & $p -BaseUrl $BaseUrl -CompanyId $CompanyId -ObligationId $ObligationId `
       -AutoStartServer:$AutoStartServer -StopServerAfter:$StopServerAfter `
       -Quiet:$Quiet -DumpJsonDir $DumpJsonDir -TimeoutMs $TimeoutMs -ReportPath $ReportPath
  }
}

function Ensure-BughunlerFile {
  param([string]$Path)
  if(-not (Test-Path $Path)){
    "# Bughunler`r`n" | Set-Content -Encoding utf8 -Path $Path
  }
}

function Append-BughunlerRegTechSmoke {
  param(
    [string]$Path,
    [string]$Date,
    [string]$Status,
    [string]$Company,
    [string[]]$Lines
  )

  Ensure-BughunlerFile -Path $Path

  $raw = Get-Content $Path -Raw -Encoding utf8
  if($null -eq $raw){ $raw = "" }
  $raw = $raw -replace "`r`n","`n" -replace "`r","`n"
  $arr = if($raw.Length -gt 0){ $raw -split "`n" } else { @() }

  # ensure main header
  if($arr.Count -eq 0 -or $arr[0] -notmatch '^\s*#\s*Bughunler\b'){
    $arr = @("# Bughunler","") + $arr
  }

  # ensure date header
  $dateRx = "^\s*##\s+$([regex]::Escape($Date))\s*$"
  $hasDate = $false
  for($i=0; $i -lt $arr.Count; $i++){
    if($arr[$i] -match $dateRx){ $hasDate = $true; break }
  }
  if(-not $hasDate){
    $arr = $arr + @("","## $Date","")
  }

  # remove old block for same date
  $markerRx = "^<!--\s*RegTechSmoke\|$([regex]::Escape($Date))\|"
  $out = New-Object System.Collections.Generic.List[string]
  $skipping = $false
  foreach($ln in $arr){
    if($ln -match $markerRx){ $skipping = $true; continue }
    if($skipping){
      if($ln.Trim().StartsWith("-")){ continue }
      if([string]::IsNullOrWhiteSpace($ln)){ continue }
      $skipping = $false
    }
    $out.Add($ln)
  }
  $arr = $out.ToArray()

  # find date header index again
  $idxDate = -1
  for($i=0; $i -lt $arr.Count; $i++){
    if($arr[$i] -match $dateRx){ $idxDate = $i; break }
  }
  if($idxDate -lt 0){
    $arr = $arr + @("","## $Date","")
    $idxDate = $arr.Count - 2
  }

  # ensure blank line after date header
  $insertPos = $idxDate + 1
  if($insertPos -ge $arr.Count){
    $arr = $arr + @("")
  } elseif(-not [string]::IsNullOrWhiteSpace($arr[$insertPos])){
    $before2 = @()
    if($insertPos -gt 0){ $before2 = $arr[0..($insertPos-1)] }
    $after2  = $arr[$insertPos..($arr.Count-1)]
    $arr = @($before2) + @("") + @($after2)
  }

  $marker = "<!-- RegTechSmoke|$Date|$Status|$Company -->"
  $block = @($marker)
  foreach($l in $Lines){
    if(-not [string]::IsNullOrWhiteSpace($l)){ $block += "- $l" }
  }
  $block += ""

  $pos = $idxDate + 2
  if($pos -gt $arr.Count){ $pos = $arr.Count }

  $before = @()
  if($pos -gt 0){ $before = $arr[0..($pos-1)] }
  $after = @()
  if($pos -lt $arr.Count){ $after = $arr[$pos..($arr.Count-1)] }

  $arr = @($before) + @($block) + @($after)
  ($arr -join "`r`n") | Set-Content -Encoding utf8 -Path $Path
}



function regcheck {
  param(
    [switch]$AutoStartServer,
    [switch]$StopServerAfter,
    [string]$ReportPath = ".\smoke_report.json"
  )

  Use-RegTechRoot {
    Ensure-RegTechEnv
    python manage.py test mevzuat_parca -v 2
    if($LASTEXITCODE -ne 0){ throw "Unit testler FAIL. Smoke calistirmadim." }

    run_smoke -AutoStartServer:$AutoStartServer -StopServerAfter:$StopServerAfter -Quiet -ReportPath $ReportPath
  }
}





Set-Alias smoke run_smoke

# --- regtodo (persisted) ---
function regtodo {
param(
    [int]$Top=5,
    [string]$Path=".\smoke_report.json",
    [switch]$WithRisk
  )

  Use-RegTechRoot {
    if(-not (Test-Path $Path)){ throw "Yok: $Path" }
    $r = Get-Content $Path -Raw -Encoding utf8 | ConvertFrom-Json
    $dash = $r.payload.dash

    $todos = $null
    foreach($k in @("todo","todo_items","todoItems")){
      if($dash.PSObject.Properties.Name -contains $k){
        $todos = $dash.$k
        break
      }
    }
    if(-not $todos){ Write-Warning "todo listesi yok (payload.dash.todo bulunamadi)."; return }

    $i = 0
    foreach($t in @($todos)){
      if($i -ge $Top){ break }

      # title (öncelik: regulation_title)
      $title = $null
      if($t.PSObject.Properties.Name -contains "regulation_title"){ $title = $t.regulation_title }
      elseif($t.PSObject.Properties.Name -contains "regulationTitle"){ $title = $t.regulationTitle }
      elseif($t.PSObject.Properties.Name -contains "title"){ $title = $t.title }
      elseif($t.PSObject.Properties.Name -contains "baslik"){ $title = $t.baslik }
      elseif($t.PSObject.Properties.Name -contains "duzenleme_title"){ $title = $t.duzenleme_title }
      elseif(($t.PSObject.Properties.Name -contains "duzenleme") -and $t.duzenleme){
        if($t.duzenleme.PSObject.Properties.Name -contains "title"){ $title = $t.duzenleme.title }
        elseif($t.duzenleme.PSObject.Properties.Name -contains "baslik"){ $title = $t.duzenleme.baslik }
      }
      if([string]::IsNullOrWhiteSpace($title)){ $title = "[baslik yok]" }

      # due
      $due = $null
      if($t.PSObject.Properties.Name -contains "due_date"){ $due = $t.due_date }
      elseif($t.PSObject.Properties.Name -contains "due"){ $due = $t.due }
      elseif($t.PSObject.Properties.Name -contains "deadline"){ $due = $t.deadline }

      # risk (opsiyonel)
      $risk = $null
      if($t.PSObject.Properties.Name -contains "risk_level"){ $risk = $t.risk_level }

      $suffix = ""
      if($due){ $suffix += " (due=$due)" }
      if($WithRisk -and $risk){ $suffix += " [risk=$risk]" }

      "{0}. {1}{2}" -f ($i+1), $title, $suffix
      $i++
    }
  }
}
# --- /regtodo ---

# --- RegTech todo defaults (override) ---

function regdaily {
  param(
    [string]$ReportPath='.\smoke_report.json',
    [switch]$CopyToClipboard,
    [string]$AppendPath='.\bughunler.md',
    [switch]$WithTodos,
    [int]$TodosTop=5,
    [switch]$TodosWithRisk
  )
  $useTodos = if($PSBoundParameters.ContainsKey('WithTodos')){ [bool]$WithTodos } else { $true }
  $useRisk  = if($PSBoundParameters.ContainsKey('TodosWithRisk')){ [bool]$TodosWithRisk } else { $true }
  regdaily2 -ReportPath $ReportPath -CopyToClipboard:$CopyToClipboard -AppendPath $AppendPath -WithTodos:$useTodos -TodosTop $TodosTop -TodosWithRisk:$useRisk
}

function regnote {
  param(
    [switch]$CopyToClipboard,
    [string]$AppendPath='.\bughunler.md',
    [switch]$Show,
    [switch]$Open,
    [string]$SavePath='.\last_regnote.txt',
    [switch]$WithTodos,
    [int]$TodosTop=5,
    [switch]$TodosWithRisk
  )
  $useTodos = if($PSBoundParameters.ContainsKey('WithTodos')){ [bool]$WithTodos } else { $true }
  $useRisk  = if($PSBoundParameters.ContainsKey('TodosWithRisk')){ [bool]$TodosWithRisk } else { $true }
  regnote2 -CopyToClipboard:$CopyToClipboard -AppendPath $AppendPath -Show:$Show -Open:$Open -SavePath $SavePath -WithTodos:$useTodos -TodosTop $TodosTop -TodosWithRisk:$useRisk
}

function gunluk_smoke {
  param(
    [string]$ReportPath='.\smoke_report.json',
    [switch]$CopyToClipboard,
    [string]$AppendPath='.\bughunler.md',
    [switch]$Show,
    [switch]$WithTodos,
    [int]$TodosTop=3,
    [switch]$TodosWithRisk
  )
  $useTodos = if($PSBoundParameters.ContainsKey('WithTodos')){ [bool]$WithTodos } else { $true }
  $useRisk  = if($PSBoundParameters.ContainsKey('TodosWithRisk')){ [bool]$TodosWithRisk } else { $true }
  gunluk_smoke2 -ReportPath $ReportPath -CopyToClipboard:$CopyToClipboard -AppendPath $AppendPath -Show:$Show -WithTodos:$useTodos -TodosTop $TodosTop -TodosWithRisk:$useRisk
}

# --- /RegTech todo defaults (override) ---


# --- RegTech doctor (persisted) ---
function regdoctor {
  param([switch]$ShowDetails)

  $rt = (Get-Command Get-RegTechRoot).ScriptBlock.File
  $code = Get-Content $rt -Raw -Encoding utf8

  $counts = [ordered]@{
    regnote = ([regex]::Matches($code,'(?m)^\s*function\s+regnote\b').Count)
    regdaily = ([regex]::Matches($code,'(?m)^\s*function\s+regdaily\b').Count)
    gunluk_smoke = ([regex]::Matches($code,'(?m)^\s*function\s+gunluk_smoke\b').Count)
    regtodo = ([regex]::Matches($code,'(?m)^\s*function\s+regtodo\b').Count)
    reglog_alias_lines = ([regex]::Matches($code,'(?m)^\s*Set-Alias\s+reglog\s+regnote\b').Count)
  }

  $cmdsOk = [ordered]@{
    regnote_calls_regnote2 = ((Get-Command regnote).ScriptBlock.ToString() -match '\bregnote2\b')
    regdaily_calls_regdaily2 = ((Get-Command regdaily).ScriptBlock.ToString() -match '\bregdaily2\b')
    gunluk_smoke_calls_gunluk_smoke2 = ((Get-Command gunluk_smoke).ScriptBlock.ToString() -match '\bgunluk_smoke2\b')
  }

  $aliasOk = [bool](Get-Alias reglog -ErrorAction SilentlyContinue)

  $result = [pscustomobject]@{
    File = $rt
    Counts = $counts
    WrappersOk = $cmdsOk
    ReglogAliasLoaded = $aliasOk
  }

  foreach($k in $counts.Keys){
    if($counts[$k] -gt 1){
      Write-Warning ('DUPLICATE: {0} = {1}' -f $k, $counts[$k])
    }
  }
  foreach($k in $cmdsOk.Keys){
    if(-not $cmdsOk[$k]){
      Write-Warning ('WRAPPER BAD: {0}' -f $k)
    }
  }
  if(-not $aliasOk){
    Write-Warning 'reglog alias yuklu degil (dot-source sirasini kontrol et).'
  }

  if($ShowDetails){
    $result | Format-List | Out-String | Write-Host
  } else {
    $result
  }
}
# --- /RegTech doctor (persisted) ---


Set-Alias reglog regnote -Force

