# Bughunler

## 2025-12-20

<!-- RegTechSmoke|2025-12-20|PASS|Test Yazılım A.Ş. -->
- Calistirma: regcheck(unit) -> run_smoke (AutoStart/Stop guvenli)
- Dogrulama: dashboard==SPA (canonical JSON)
- Toggle: PATCH true/false; todo/completed + stats invariant
- Rapor: smoke_report.json (PASS, ms=22830, base=http://127.0.0.1:8000, company=Test Yazılım A.Ş.)

## 2025-12-19

<!-- RegTechSmoke|2025-12-19|PASS|Test Yazılım A.Ş. -->
- Calistirma: regcheck(unit) → run_smoke (AutoStart/Stop guvenli)
- Dogrulama: dashboard==SPA (canonical JSON)
- Toggle: PATCH true/false; todo/completed + stats invariant
- Rapor: smoke_report.json (PASS, ms=19413, base=http://127.0.0.1:8000, company=Test Yazılım A.Ş.)





## 2025-12-21

<!-- RegTechSmoke|2025-12-21|PASS|Test Yazılım A.Ş. -->
- Calistirma: regcheck(unit) -> run_smoke (AutoStart/Stop guvenli)
- Dogrulama: dashboard==SPA (canonical JSON)
- Toggle: PATCH true/false; todo/completed + stats invariant
- Rapor: smoke_report.json (PASS, ms=19880, base=http://127.0.0.1:8000, company=Test Yazılım A.Ş.)
- TODO 1: KDV Genel Tebliği (Seri No: 42) Değişikliği (due=2025-12-13) [risk=high]
- TODO 2: KOSGEB Dijital Dönüşüm Desteği (due=2025-12-13) [risk=low]

