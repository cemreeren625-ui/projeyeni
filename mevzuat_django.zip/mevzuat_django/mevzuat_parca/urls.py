# URL route tanımlamak için path fonksiyonu
from django.urls import path

# views içindeki tüm fonksiyonları/class-based view'ları içeri alıyor
# (iyi pratik değil, mümkünse tek tek import et)
from .views import *

# Django admin paneli route'u için
from django.contrib import admin


urlpatterns = [
    # Admin paneli: /admin/
    path("admin/", admin.site.urls),

    # ---- JSON API’ler ----

    # SPA şirket listesi (HTML template render ediyor): /api/companies-spa/
    path("api/companies-spa/", companies_spa_list, name="companies_spa_list"),

    # SPA şirket detay (HTML template render ediyor): /api/companies-spa/<id>/
    path("api/companies-spa/<int:pk>/", companies_spa_detail, name="companies_spa_detail"),

    # SPA dashboard JSON endpoint: /api/companies-spa/<id>/dashboard/
    # React burayı fetch ile çekiyor
    path("api/companies-spa/<int:pk>/dashboard/", sirket_dashboard_api),

    # DRF: Şirket liste + oluştur (JSON): /api/companies/
    path("api/companies/", SirketListCreateView.as_view(), name="Sirket-list-create"),

    # DRF: Şirket detay / güncelle / sil (JSON): /api/companies/<id>/
    path("api/companies/<int:pk>/", SirketDetailView.as_view(), name="Sirket-detail"),

    # DRF: Şirket dashboard (JSON): /api/companies/<id>/dashboard/
    # (Bu senin "eski" API dashboard’un, ayrı endpoint)
    path("api/companies/<int:pk>/dashboard/", Sirket_dashboard, name="Sirket-dashboard"),

    # HTML form aksiyonu: obligation tamamla (POST): /api/obligations/<id>/complete/
    path("api/obligations/<int:pk>/complete/", obligation_complete, name="obligation-complete"),

    # HTML form aksiyonu: obligation resetle (POST): /api/obligations/<id>/reset/
    path("api/obligations/<int:pk>/reset/", obligation_reset, name="obligation-reset"),

    # SPA/JSON: obligation durumunu PATCH ile değiştir: /api/obligations/<id>/status/
    # (React "Tamamlandı" / "Geri al" burada PATCH atıyor)
    path("api/obligations/<int:pk>/status/", obligation_status_api, name="obligation-status-api"),

    # DRF: Mevzuat liste + oluştur (JSON): /api/Duzenlemes/
    path("api/Duzenlemes/", DuzenlemeListCreateView.as_view(), name="Duzenleme-list-create"),

    # DRF: Mevzuat detay/güncelle/sil (JSON): /api/Duzenlemes/<id>/
    path("api/Duzenlemes/<int:pk>/", DuzenlemeDetailView.as_view(), name="Duzenleme-detail"),

    # ---- HTML sayfalar (eski panel) ----

    # Eski HTML şirket listesi: /api/companies-dashboard/
    path("api/companies-dashboard/", sirket_list_page, name="sirket-list-page"),

    # Eski HTML riskli şirketler listesi: /api/companies-risky/
    path("api/companies-risky/", sirket_riskli_list_page, name="sirket-riskli-list-page"),

    # Eski HTML şirket dashboard sayfası: /api/companies/<id>/dashboard-page/
    path("api/companies/<int:pk>/dashboard-page/", sirket_dashboard_page, name="sirket-dashboard-page"),

]
