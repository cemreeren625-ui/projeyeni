# DRF'nin generic view sınıfları (ListCreate, RetrieveUpdateDestroy vb.) için
from rest_framework import generics

# Proje modellerini içeri alıyoruz (Sirket, Duzenleme, SirketObligation)
from .models import Sirket, Duzenleme, SirketObligation

# Serializer'ları içeri alıyoruz (SirketSerializer, DuzenlemeSerializer vb.)
# NOT: '*' wildcard önerilmez ama şimdilik sende böyle olduğu için bıraktım.
from .serilestiriciler import *

# DRF ile function-based view yazmak için decorator
from rest_framework.decorators import api_view

# DRF Response (JSON döndürmek için)
from rest_framework.response import Response

# 404 yoksa döndürmek ve template render etmek için
from django.shortcuts import get_object_or_404, render, redirect

# Tarih ve süre hesabı için
from datetime import date, timedelta

# POST zorunluluğu için (HTML form action gibi)
from django.views.decorators.http import require_POST

# HTTP status kodları için (200, 400 vb.)
from rest_framework import status


def hesapla_sirket_skoru(sirket: Sirket):
    """
    Verilen şirket için:
    - uyum skoru (0-100)
    - istatistikler
    - to-do listesi
    - completed listesi
    döner.
    Hem HTML panel hem JSON API burayı kullanacak.
    """

    # Bu şirkete ait, uygulanabilir (is_applicable=True) yükümlülükleri çek
    # select_related("duzenleme") ile her obligation için ilişkili duzenleme tek sorguda gelir
    obligations = SirketObligation.objects.filter(
        sirket=sirket,
        is_applicable=True,
    ).select_related("duzenleme")

    # Bugünün tarihini al
    today = date.today()

    # Skor başlangıç değeri
    score = 100

    # Açık (uyumsuz) yükümlülük sayısı
    open_count = 0

    # Gecikmiş (due_date < today) yükümlülük sayısı
    overdue_count = 0

    # UI'da gösterilecek yapılacaklar listesi (uyumsuzlar)
    todo_items = []

    # UI'da gösterilecek tamamlananlar listesi
    completed_items = []

    # Etki türüne göre ceza puanı tablosu
    impact_penalties = {
        "zorunlu": 15,          # zorunluysa daha ağır ceza
        "risk": 10,             # risk bazlı ceza
        "opsiyonel_tesvik": 5,  # teşvikse ceza az
    }

    # Risk seviyesine göre ceza puanı tablosu
    risk_penalties = {
        "low": 0,
        "medium": 3,
        "high": 7,
    }

    # Tüm yükümlülükleri tek tek gez
    for obl in obligations:
        # Bu yükümlülüğün bağlı olduğu düzenlemeyi al
        reg = obl.duzenleme

        # 1) Eğer yükümlülük tamamlandıysa completed listesine ekle
        if obl.is_compliant:
            completed_items.append({
                "obligation_id": obl.id,         # obligation PK
                "regulation_id": reg.id,         # düzenleme PK
                "regulation_title": reg.title,   # düzenleme başlığı
                "due_date": obl.due_date,        # son tarih
                "risk_level": obl.risk_level,    # risk seviyesi
                "impact_type": reg.impact_type,  # etki türü
            })

            # Eğer bu tamamlanan şey teşvik ise +bonus ver
            if reg.impact_type == "opsiyonel_tesvik":
                score += 5

            # Tamamlandıysa ceza hesabına girmeden bir sonraki obligation'a geç
            continue

        # 2) Buraya geldiyse: uyumsuz/açık yükümlülük
        open_count += 1

        # Etki cezasını bul (yoksa 0)
        impact_pen = impact_penalties.get(reg.impact_type or "", 0)

        # Risk cezasını bul (risk_level boşsa medium kabul et)
        risk_pen = risk_penalties.get(obl.risk_level or "medium", 0)

        # Tarihe bağlı ceza
        date_pen = 0

        # due_date varsa gecikme / yaklaşma cezası uygula
        if obl.due_date:
            if obl.due_date < today:
                overdue_count += 1   # gecikmiş say
                date_pen = 10        # gecikme cezası
            elif obl.due_date <= today + timedelta(days=7):
                date_pen = 5         # 7 gün içinde yaklaşan ceza

        # Toplam ceza = etki + risk + tarih
        total_penalty = impact_pen + risk_pen + date_pen

        # Skordan cezayı düş
        score -= total_penalty

        # Yapılacaklar listesine ekle
        todo_items.append({
            "obligation_id": obl.id,
            "regulation_id": reg.id,
            "regulation_title": reg.title,
            "due_date": obl.due_date,
            "risk_level": obl.risk_level,
            "impact_type": reg.impact_type,
        })

    # Skoru 0-100 aralığına sıkıştır (clamp)
    if score < 0:
        score = 0
    if score > 100:
        score = 100

    # JSON olarak dönecek veri
    return {
        "uyum_skoru": score,  # frontend'in okuduğu alan
        "score": score,       # alternatif isim (istersen kaldır)
        "stats": {
            "total_obligations": obligations.count(),
            "open_obligations": open_count,
            "overdue_obligations": overdue_count,
        },
        "todo": todo_items,
        "completed": completed_items,
    }


# /api/companies/  -> şirket listele + oluştur
class SirketListCreateView(generics.ListCreateAPIView):
    # Varsayılan query
    queryset = Sirket.objects.all().order_by("-id")

    # Kullanılacak serializer
    serializer_class = SirketSerializer

    def list(self, request, *args, **kwargs):
        """
        Şirket listesi:
        - ?sector=yazilim  → sektöre göre filtre
        - ?risky=true      → skor < threshold olanları getir (default 80)
        - ?threshold=70    → eşiği override et
        """
        # Temel query'i al
        queryset = self.get_queryset()

        # Query params çek
        sector = request.query_params.get("sector")
        risky = request.query_params.get("risky")
        threshold_param = request.query_params.get("threshold")

        # sector filtresi uygula
        if sector:
            queryset = queryset.filter(sector=sector)

        # serializer ile listeyi JSON'a çevir
        serializer = self.get_serializer(queryset, many=True)
        data = list(serializer.data)

        # riskli=true geldiyse eşik altını filtrele
        if risky == "true":
            try:
                threshold = int(threshold_param) if threshold_param is not None else 80
            except ValueError:
                threshold = 80

            # NOT: compliance_score serializer'da yoksa burası çalışmaz.
            # Eğer hesaplanmış bir alan ise serializer'a eklemelisin.
            data = [
                item for item in data
                if item.get("compliance_score") is not None
                and item["compliance_score"] < threshold
            ]

        # Sonuç döndür
        return Response(data)


# /api/companies/<id>/  -> şirket getir/güncelle/sil
class SirketDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Sirket.objects.all()
    serializer_class = SirketSerializer


# /api/Duzenlemes/ -> mevzuat listele/oluştur
class DuzenlemeListCreateView(generics.ListCreateAPIView):
    queryset = Duzenleme.objects.all().order_by("-publish_date")
    serializer_class = DuzenlemeSerializer


# /api/Duzenlemes/<id>/ -> mevzuat getir/güncelle/sil
class DuzenlemeDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Duzenleme.objects.all()
    serializer_class = DuzenlemeSerializer


@api_view(["GET"])
def Sirket_dashboard(request, pk):
    # Şirketi bul, yoksa 404
    sirket = get_object_or_404(Sirket, pk=pk)

    # Skor + listeleri hesapla
    sonuc = hesapla_sirket_skoru(sirket)

    # JSON response hazırla
    data = {
        "sirket": SirketSerializer(sirket).data,  # şirket detayını da ver
        "uyum_skoru": sonuc["score"],             # skor (uyum_skoru yerine score kullanmışsın)
        "stats": sonuc["stats"],
        "todo": sonuc["todo"],
        "completed": sonuc["completed"],
    }

    # JSON döndür
    return Response(data)


def sirket_dashboard_page(request, pk):
    # Şirketi bul
    sirket = get_object_or_404(Sirket, pk=pk)

    # Skoru hesapla
    sonuc = hesapla_sirket_skoru(sirket)

    # Template context hazırla
    context = {
        "sirket": sirket,
        "compliance_score": sonuc["score"],
        "stats": sonuc["stats"],
        "todo": sonuc["todo"],
        "completed": sonuc["completed"],
    }

    # HTML template render et
    return render(request, "sirket_dashboard.html", context)


def sirket_list_page(request):
    # URL'den sector filtresini al
    selected_sector = request.GET.get("sector")

    # Şirketleri al
    sirket_qs = Sirket.objects.all().order_by("name")

    # sector seçiliyse filtrele
    if selected_sector:
        sirket_qs = sirket_qs.filter(sector=selected_sector)

    # Her şirket için skor hesapla
    sirketler = []
    for s in sirket_qs:
        sonuc = hesapla_sirket_skoru(s)
        sirketler.append({
            "sirket": s,
            "score": sonuc["score"],
        })

    # Template context
    context = {
        "sirketler": sirketler,
        "selected_sector": selected_sector,
        "sector_choices": Sirket.SECTOR_CHOICES,
    }

    # HTML render
    return render(request, "sirket_list.html", context)


def sirket_riskli_list_page(request):
    """
    Skoru belirli eşikten düşük olan şirketleri listeler.
    URL: /api/companies-risky/
    ?max_score=70 ile eşik değişebilir.
    """
    # threshold parametresini al, yoksa 80
    try:
        threshold = int(request.GET.get("max_score", "80"))
    except ValueError:
        threshold = 80

    # Şirketleri al
    sirket_qs = Sirket.objects.all().order_by("name")

    # Eşik altını biriktir
    sirketler = []
    for s in sirket_qs:
        sonuc = hesapla_sirket_skoru(s)
        if sonuc["score"] < threshold:
            sirketler.append({
                "sirket": s,
                "score": sonuc["score"],
            })

    # Template context
    context = {
        "sirketler": sirketler,
        "threshold": threshold,
    }

    # HTML render
    return render(request, "sirket_riskli_list.html", context)


@require_POST
def obligation_complete(request, pk):
    """
    HTML form ile: yükümlülüğü tamamla
    """
    # Obligation bul
    obligation = get_object_or_404(SirketObligation, pk=pk)

    # Tamamlandı yap
    obligation.is_compliant = True
    obligation.save()

    # İlgili şirketin HTML dashboard'una yönlendir
    sirket_id = obligation.sirket_id
    return redirect(f"/api/companies/{sirket_id}/dashboard-page/")


@require_POST
def obligation_reset(request, pk):
    """
    HTML form ile: yükümlülüğü geri al (uyumsuz yap)
    """
    obligation = get_object_or_404(SirketObligation, pk=pk)
    obligation.is_compliant = False
    obligation.save()

    sirket_id = obligation.sirket_id
    return redirect(f"/api/companies/{sirket_id}/dashboard-page/")


@api_view(["PATCH"])
def obligation_status_api(request, pk):
    """
    JSON API:
    PATCH ile is_compliant günceller ve güncel skor + listeleri döndürür.
    """
    # Obligation bul
    obligation = get_object_or_404(SirketObligation, pk=pk)

    # Body'den is_compliant al (yoksa True)
    is_compliant = request.data.get("is_compliant", True)

    # Python bool'e çevir
    obligation.is_compliant = bool(is_compliant)

    # Kaydet
    obligation.save()

    # Skoru yeniden hesapla
    result = hesapla_sirket_skoru(obligation.sirket)

    # JSON response hazırla
    data = {
        "obligation": {
            "id": obligation.id,
            "sirket_id": obligation.sirket_id,
            "is_compliant": obligation.is_compliant,
        },
        "compliance_score": result["score"],
        "stats": result["stats"],
        "todo": result["todo"],
        "completed": result["completed"],
    }

    # 200 OK ile dön
    return Response(data, status=status.HTTP_200_OK)


def companies_spa_list(request):
    """
    SPA liste sayfası (HTML)
    """
    # Şirketleri al
    sirketler = Sirket.objects.all().order_by("id")

    # Liste template render
    return render(request, "companies_spa_list.html", {"sirketler": sirketler})


def companies_spa_detail(request, pk):
    """
    SPA detay sayfası (HTML)
    """
    # Şirketi bul
    sirket = get_object_or_404(Sirket, pk=pk)

    # Detay template render (data-company-id burada basılıyor)
    return render(request, "companies_spa_detail.html", {
        "company_id": sirket.pk,
        "company_name": sirket.name,
    })


@api_view(["GET"])
def sirket_dashboard_api(request, pk):
    """
    SPA'nın çağırdığı dashboard JSON endpoint'i:
    /api/companies-spa/<id>/dashboard/
    """
    # Şirketi bul
    sirket = get_object_or_404(Sirket, pk=pk)

    # Hesapla ve JSON dön
    return Response(hesapla_sirket_skoru(sirket))
